import { Vector3 } from "@babylonjs/core";
import type { GraphEntity } from "../visualscript/nodes";
import type { GameEntity, GameScene } from "./GameEntity";

/** The entity as visual script nodes see it: position, rotation and removal go through the game entity and scene. */
export function graphEntity(entity: GameEntity, game: GameScene): GraphEntity {
  return {
    get name() {
      return entity.name;
    },
    getWorldPosition: () => {
      const at = entity.getWorldPosition();
      return { x: at.x, y: at.y, z: at.z };
    },
    setWorldPosition: (position) => entity.node.setAbsolutePosition(new Vector3(position.x, position.y, position.z)),
    rotate: (yaw, pitch, roll) => entity.rotate(yaw, pitch, roll),
    destroy: () => game.removeEntity(entity),
  };
}
