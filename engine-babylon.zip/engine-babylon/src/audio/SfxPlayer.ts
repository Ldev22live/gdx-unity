import { generateSfxr, isKnownSound, sfxrPreset, SFXR_PRESET_NAMES, SFXR_SAMPLE_RATE } from "./sfxr";

/** Plays one generated sound. The browser implementation is {@link WebAudioSfxOutput}; tests use a recording fake. */
export interface SfxOutput {
  /**
   * Starts {@code samples} (mono, -1..1) once, at linear {@code volume} 0..1 and {@code pitch} times the speed.
   * Must not block; called from the game loop.
   */
  play(samples: Float32Array, sampleRate: number, volume: number, pitch: number): void;
}

/** Sound effects of a played scene (TD-043): makes each sound once, then replays it from memory on every cue. */
export class SfxPlayer {
  private readonly sounds = new Map<string, Float32Array>();

  constructor(private readonly output: SfxOutput) {}

  /** Whether {@code sound} is a factory sound name. */
  static isKnown(sound: string): boolean {
    return isKnownSound(sound);
  }

  /** The factory sound names, for messages. */
  static get names(): readonly string[] {
    return SFXR_PRESET_NAMES;
  }

  /** Makes {@code sound} now so the first {@link play} does not pay for it. @throws Error for an unknown name. */
  prepare(sound: string): Float32Array {
    let samples = this.sounds.get(sound);
    if (!samples) {
      samples = generateSfxr(sfxrPreset(sound));
      this.sounds.set(sound, samples);
    }
    return samples;
  }

  /**
   * Plays a sound once.
   *
   * @throws Error for an unknown sound, a volume outside 0..1 or a pitch that is not above 0
   */
  play(sound: string, volume: number, pitch: number): void {
    if (!(volume >= 0 && volume <= 1)) throw new Error(`volume must be within 0 to 1: ${volume}`);
    if (!(pitch > 0) || !Number.isFinite(pitch)) throw new Error(`pitch must be above 0: ${pitch}`);
    this.output.play(this.prepare(sound), SFXR_SAMPLE_RATE, volume, pitch);
  }
}

/**
 * Sound out of the browser's AudioContext. The context is created on the first sound, which happens after the click on
 * Play, because browsers keep audio silent until the user has interacted with the page. Each sound is an AudioBuffer
 * made once and replayed through a one-shot source with a gain.
 */
export class WebAudioSfxOutput implements SfxOutput {
  private context: AudioContext | null = null;
  private readonly buffers = new WeakMap<Float32Array, AudioBuffer>();

  play(samples: Float32Array, sampleRate: number, volume: number, pitch: number): void {
    const context = this.ensureContext();
    if (context.state === "suspended") void context.resume();
    let buffer = this.buffers.get(samples);
    if (!buffer) {
      buffer = context.createBuffer(1, samples.length, sampleRate);
      buffer.copyToChannel(samples as Float32Array<ArrayBuffer>, 0);
      this.buffers.set(samples, buffer);
    }
    const source = context.createBufferSource();
    source.buffer = buffer;
    source.playbackRate.value = pitch;
    const gain = context.createGain();
    gain.gain.value = volume;
    source.connect(gain).connect(context.destination);
    source.start();
  }

  /** Closes the AudioContext; a later sound opens a new one. */
  dispose(): void {
    void this.context?.close();
    this.context = null;
  }

  private ensureContext(): AudioContext {
    this.context ??= new AudioContext();
    return this.context;
  }
}
